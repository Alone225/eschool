package com.magicsoft.eschool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EschoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
