package entites;

import java.io.Serializable;
import java.util.Collection;
public class Dossier implements Serializable {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  String id_doc;
	 private String path;
	 private Collection<Cours>cours;
	public Dossier() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dossier(String path, Collection<Cours> cours) {
		super();
		this.path = path;
		this.cours = cours;
	}
	public String getId_doc() {
		return id_doc;
	}
	public void setId_doc(String id_doc) {
		this.id_doc = id_doc;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public Collection<Cours> getCours() {
		return cours;
	}
	public void setCours(Collection<Cours> cours) {
		this.cours = cours;
	}
	 
	 

}
