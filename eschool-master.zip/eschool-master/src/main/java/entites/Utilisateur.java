package entites;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;



public class Utilisateur implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long idutilisateur;
	private String nom;
	private String prenoms;
	private String sexe;
	private Date date_naiss;
	private String email;
	private String  numero_tel;
	private Collection<Activite>activites;
	public Utilisateur() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Utilisateur(String nom, String prenoms, String sexe, Date date_naiss, String email, String numero_tel) {
		super();
		this.nom = nom;
		this.prenoms = prenoms;
		this.sexe = sexe;
		this.date_naiss = date_naiss;
		this.email = email;
		this.numero_tel = numero_tel;
	}
	public Long getIdutilisateur() {
		return idutilisateur;
	}
	public void setIdutilisateur(Long idutilisateur) {
		this.idutilisateur = idutilisateur;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenoms() {
		return prenoms;
	}
	public void setPrenoms(String prenoms) {
		this.prenoms = prenoms;
	}
	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	public Date getDate_naiss() {
		return date_naiss;
	}
	public void setDate_naiss(Date date_naiss) {
		this.date_naiss = date_naiss;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumero_tel() {
		return numero_tel;
	}
	public void setNumero_tel(String numero_tel) {
		this.numero_tel = numero_tel;
	}
	public Collection<Activite> getActivites() {
		return activites;
	}
	public void setActivites(Collection<Activite> activites) {
		this.activites = activites;
	}
   
}
   