package entites;

import java.io.Serializable;

public class Activite implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id_activite;
	private String libelle_activite;
	private Long noteactivite;
	public Activite() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Activite(String id_activite, String libelle_activite, Long noteactivite) {
		super();
		this.id_activite = id_activite;
		this.libelle_activite = libelle_activite;
		this.noteactivite = noteactivite;
	}
	public String getId_activite() {
		return id_activite;
	}
	public void setId_activite(String id_activite) {
		this.id_activite = id_activite;
	}
	public String getLibelle_activite() {
		return libelle_activite;
	}
	public void setLibelle_activite(String libelle_activite) {
		this.libelle_activite = libelle_activite;
	}
	public Long getNoteactivite() {
		return noteactivite;
	}
	public void setNoteactivite(Long noteactivite) {
		this.noteactivite = noteactivite;
	}

}
