package entites;

import java.io.Serializable;

public class Role implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String idrole;
	 
	private String libelle;

	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Role(String libelle) {
		super();
		this.libelle = libelle;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public String getIdrole() {
		return idrole;
	}

	public void setIdrole(String idrole) {
		this.idrole = idrole;
	}
   
}
