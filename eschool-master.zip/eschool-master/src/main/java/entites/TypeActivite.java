package entites;

import java.io.Serializable;
import java.util.Collection;

public class TypeActivite implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id_type;
	private String libelle_typeactivite;
	private Collection<Activite>activites;
	public TypeActivite() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TypeActivite(String id_type, String libelle_typeactivite, Collection<Activite> activites) {
		super();
		this.id_type = id_type;
		this.libelle_typeactivite = libelle_typeactivite;
		this.activites = activites;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getLibelle_typeactivite() {
		return libelle_typeactivite;
	}
	public void setLibelle_typeactivite(String libelle_typeactivite) {
		this.libelle_typeactivite = libelle_typeactivite;
	}
	public Collection<Activite> getActivites() {
		return activites;
	}
	public void setActivites(Collection<Activite> activites) {
		this.activites = activites;
	}
	
	
	


}
