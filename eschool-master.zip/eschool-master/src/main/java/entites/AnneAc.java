package entites;

import java.io.Serializable;
import java.util.Collection;

public class AnneAc implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  String id_an;
	private String libelle_an;
	private Collection<Cours>cours;
	private Collection<Typesem>typesems;
	public AnneAc() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AnneAc(String id_an, String libelle_an, Collection<Cours> cours, Collection<Typesem> typesems) {
		super();
		this.id_an = id_an;
		this.libelle_an = libelle_an;
		this.cours = cours;
		this.typesems = typesems;
	}
	
	public String getId_an() {
		return id_an;
	}
	public void setId_an(String id_an) {
		this.id_an = id_an;
	}
	public String getLibelle_an() {
		return libelle_an;
	}
	public void setLibelle_an(String libelle_an) {
		this.libelle_an = libelle_an;
	}
	public Collection<Cours> getCours() {
		return cours;
	}
	public void setCours(Collection<Cours> cours) {
		this.cours = cours;
	}
	public Collection<Typesem> getTypesems() {
		return typesems;
	}
	public void setTypesems(Collection<Typesem> typesems) {
		this.typesems = typesems;
	}
	
}
