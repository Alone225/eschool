package entites;

import java.io.Serializable;

public class Typesem implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code_semtrim;
	private String libelle_semtrim;
	public Typesem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Typesem(String code_semtrim, String libelle_semtrim) {
		super();
		this.code_semtrim = code_semtrim;
		this.libelle_semtrim = libelle_semtrim;
	}
	public String getCode_semtrim() {
		return code_semtrim;
	}
	public void setCode_semtrim(String code_semtrim) {
		this.code_semtrim = code_semtrim;
	}
	public String getLibelle_semtrim() {
		return libelle_semtrim;
	}
	public void setLibelle_semtrim(String libelle_semtrim) {
		this.libelle_semtrim = libelle_semtrim;
	}
	
	

}
