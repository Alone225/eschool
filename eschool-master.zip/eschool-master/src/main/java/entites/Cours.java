package entites;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import org.apache.tomcat.jni.Time;

public class Cours implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id_cours;
	private String libelle_cours;
	private Date datecours;
	private Time hdebut;
	private Time hfin;
	private Integer effectif;
	private Collection<Activite>activites;
	
	public Cours() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cours(String id_cours, String libelle_cours, Date datecours, Time hdebut, Time hfin, Integer effectif,
			Collection<Activite> activites) {
		super();
		this.id_cours = id_cours;
		this.libelle_cours = libelle_cours;
		this.datecours = datecours;
		this.hdebut = hdebut;
		this.hfin = hfin;
		this.effectif = effectif;
		this.activites = activites;
		
	}
	public String getId_cours() {
		return id_cours;
	}
	public void setId_cours(String id_cours) {
		this.id_cours = id_cours;
	}
	public String getLibelle_cours() {
		return libelle_cours;
	}
	public void setLibelle_cours(String libelle_cours) {
		this.libelle_cours = libelle_cours;
	}
	public Date getDatecours() {
		return datecours;
	}
	public void setDatecours(Date datecours) {
		this.datecours = datecours;
	}
	public Time getHdebut() {
		return hdebut;
	}
	public void setHdebut(Time hdebut) {
		this.hdebut = hdebut;
	}
	public Time getHfin() {
		return hfin;
	}
	public void setHfin(Time hfin) {
		this.hfin = hfin;
	}
	public Integer getEffectif() {
		return effectif;
	}
	public void setEffectif(Integer effectif) {
		this.effectif = effectif;
	}
	public Collection<Activite> getActivites() {
		return activites;
	}
	public void setActivites(Collection<Activite> activites) {
		this.activites = activites;
	}
	
	

}
